let frames=[],N=90,idx=0,mode='auto',playing=true,fps=4.5,lastT=0,dragStart=null;
function preload(){for(let i=0;i<N;i++)frames.push(loadImage(`frames/frame_${String(i).padStart(3,'0')}.jpg`));}
function setup(){let c=createCanvas(900,520);c.parent('canvas-holder');imageMode(CORNER);frameRate(60);}
function draw(){background(30);if(mode==='auto'&&playing){let now=millis();if(now-lastT>=1000/fps){idx=(idx+1)%N;lastT=now;}} 
  // paper stack
  noStroke();fill(0,30);rect(12,15,width-24,height-24,10);
  image(frames[idx],0,0,width,height);
  // page curl accent
  if(mode==='auto'&&playing){let f=(millis()%int(1000/fps))/(1000/fps);stroke(150,150,150,100);strokeWeight(2);line(width-f*35,5,width-f*35,height-5);}
  document.getElementById('slider').value=idx;
}
function setMode(m){mode=m;playing=m==='auto';document.getElementById('auto').classList.toggle('active',m==='auto');document.getElementById('manual').classList.toggle('active',m==='manual');document.getElementById('play').textContent=playing?'Ⅱ 暂停':'▶ 播放';}
function setFPS(v){fps=Number(v);}
function seekFrame(v){idx=constrain(Number(v),0,N-1);mode='manual';playing=false;sync();}
function nextFrame(){idx=min(N-1,idx+1);sync();}
function prevFrame(){idx=max(0,idx-1);sync();}
function firstFrame(){idx=0;sync();}
function lastFrame(){idx=N-1;sync();}
function togglePlay(){playing=!playing;if(playing)mode='auto';sync();}
function sync(){document.getElementById('slider').value=idx;document.getElementById('play').textContent=playing?'Ⅱ 暂停':'▶ 播放';document.getElementById('auto').classList.toggle('active',mode==='auto');document.getElementById('manual').classList.toggle('active',mode==='manual');}
function mousePressed(){dragStart={x:mouseX,y:mouseY};}
function mouseReleased(){if(!dragStart)return;let dx=mouseX-dragStart.x;if(abs(dx)>30){mode='manual';playing=false;if(dx<0)nextFrame();else prevFrame();sync();}else if(mode==='manual'){if(mouseX<width*.35)prevFrame();else if(mouseX>width*.65)nextFrame();}dragStart=null;}
function keyPressed(){if(keyCode===RIGHT_ARROW){mode='manual';playing=false;nextFrame();sync();}if(keyCode===LEFT_ARROW){mode='manual';playing=false;prevFrame();sync();}if(key===' '){togglePlay();return false;}}
