# BT-Panel Web App 通用部署 SOP（公共版）

> 適用：任何 FastAPI 網頁專案，透過 bt-panel 部署到伺服器。
> 不限特定專案；可給任何 AI Agent 照做（AI 有 FTP + 面板 HTTP 權限即可全自動上架自己的 zip）。
> 舊的 `DEPLOY_SOP.md` / `AI_DEPLOY_SOP.md`（DSP_PRO_2 專用）內容已被本文件取代。

---

## 0. 這個面板怎麼部署 Web App（先懂規則，坑就在這）

面板部署一個 app 的流程：
```
上傳 zip → 解壓(單一頂層資料夾自動拉平) → 偵測進入點(main:app 等) → 建 venv
         → 離線 pip 裝依賴 → 開端口(留空自動抓 9000+) → 啟動 uvicorn
```

面板只認這幾件事，踩錯就報錯：

| 規則 | 要求 | 若違反 |
|---|---|---|
| **進入點檔案名** | `main.py` / `app.py` / `run.py` / `server.py` / `index.py` | `無法偵測進入點` |
| **進入點內容** | 檔內要有 `app = FastAPI()`（或 `app =` / `application =`） | `無法偵測進入點` |
| **zip 結構** | 頂層直接是 `.py` + `requirements.txt`（扁平），或單一資料夾自動拉平 | 殘留檔擋住拉平 → 偵測失敗 |
| **requirements.txt** | 一行一個依賴；**只裝得到伺服器離線包 `deploy\offline_pkgs` 裡有的 .whl** | `No matching distribution found for XXX` |
| **uvicorn** | 永遠自動裝，不用列 | — |
| **port** | 留空 → 自動抓 9000+（`free-port`） | — |
| **app 名稱** | 只限英數字、`_`、`-`（1-40 字元） | 400 錯誤 |

> ⚠️ 最重要的坑：**離線安裝（--no-index --find-links）只認伺服器離線包裡實體存在的 wheel**。
> 你要用的每個依賴，伺服器離線包 `C:\bt-panel\deploy\offline_pkgs\` 都必須有對應的 .whl。
> 檢查：`Get-ChildItem C:\bt-panel\deploy\offline_pkgs\*.whl | Measure-Object`
> 一般 FastAPI 面版預設離線包含：fastapi、uvicorn、pydantic、pydantic-settings、starlette、psutil、PyJWT、bcrypt 等 20+ 個。
> 若你的專案用到別套件（如 pymysql、requests、sqlalchemy…），**先確認離線包有沒有**，缺就要先補 wheel 進伺服器離線包。

---

## 1. FTP 連線與上傳（AI 一定要會）

伺服器提供 FTP，**AI 用 FTP 檢查/補離線包、上傳檔案用**。連線資訊如下：

| 項目 | 值 |
|---|---|
| FTP 伺服器 | `10.175.22.26` |
| 連接埠 | 21（預設） |
| 使用者名稱 | `bt` |
| 密碼 | `114253..z` |
| FTP 根路徑 | `C:\bt-panel`（面板安裝根目錄） |
| 離線包路徑（FTP） | `/deploy/offline_pkgs/`（= 伺服器 `C:\bt-panel\deploy\offline_pkgs\`） |

常用 FTP 指令（PowerShell / curl，帳密統一 `bt:114253..z`）：

```powershell
# 1) 列出離線包有哪些 wheel（先確認 requirements 每個依賴都找得到）
curl.exe -s -u "bt:114253..z" "ftp://10.175.22.26/deploy/offline_pkgs/" --list-only

# 2) 上傳缺失的 wheel 進離線包（key：pip download 產的 .whl 才能裝）
curl.exe -s -u "bt:114253..z" -T "C:\…\pymysql-1.2.0-py3-none-any.whl" "ftp://10.175.22.26/deploy/offline_pkgs/pymysql-1.2.0-py3-none-any.whl"

# 3) 檢查上傳成功
curl.exe -s -u "bt:114253..z" "ftp://10.175.22.26/deploy/offline_pkgs/pymysql-1.2.0-py3-none-any.whl" --list-only

# 4) 測試 FTP 通不通
curl.exe -s -u "bt:114253..z" "ftp://10.175.22.26/" --list-only
```

> 💡 wheel 來源：開發機用 `pip download --only-binary :all: --python-version 313 --platform win_amd64 <套件> -d tmp` 產出後再上傳（見 §7）。
> 💡 補完離線包後，重新上傳 app 即可（面板重建 venv 時就會裝到新 wheel）。

---

## 2. 面板 HTTP API（部署 zip 就走這裡，含 IP／憑證）

面板本身是 **FastAPI 服務**，上傳 zip、啟動、查狀態全是 HTTP API，**不需要登入網頁**。

| 項目 | 值 |
|---|---|
| 面板 URL | `http://10.175.22.26:8888`（此面板 IP；若換伺服器請帶入實際 IP） |
| 登入帳號 | `admin` |
| 登入密碼 | `admin123`（面板預設；若已改過請向管理員索取） |
| 認證方式 | 登入後拿 `data.token`，之後每個 API 帶 `Authorization: Bearer <token>` |
| 回應格式 | 統一 `{"code":0, "msg":"...", "data":{...}}`；**`code==0` 才代表成功**，否則看 `msg` |

**端點總表（全部需 Bearer token）：**

| 方法 路徑 | 用途 | 關鍵參數 |
|---|---|---|
| `POST /api/auth/login` | 登入取 token | body JSON `{"username","password"}` → `data.token` |
| `GET /api/apps` | 列全部 app | — |
| `GET /api/apps/free-port` | 抓一個空閒端口 | → `data.port` |
| `POST /api/apps/upload` | **上傳 zip 部署 app** | multipart：`file`(zip)、`name`、`port`(留空自動抓)、`entry`(如 `main:app`) |
| `GET /api/apps/{name}` | 查 app 狀態（含 `status`：installing / running / stopped / error） | — |
| `POST /api/apps/{name}/start` | 啟動 app | — |
| `POST /api/apps/{name}/stop` | 停止 app | — |
| `POST /api/apps/{name}/restart` | 重啟 app | — |
| `GET /api/apps/{name}/logs?max_lines=200` | 看安裝/執行日誌（排錯用） | — |
| `DELETE /api/apps/{name}` | 刪除 app（先刪再傳可避免同名 400） | — |
| `POST /api/system/restart` | **重啟面板本身**（AI 可遠端重啟，不需碰伺服器） | 回 200 後 ~4 秒自動重啟，稍候再查 |
| `GET /api/system/info` | 面板版本/PID/是否系統管理員 | — |

**AI 標準流程（curl 可直接照做）**：

> 🛡️ **所有 HTTP 操作都會自動留下稽核痕跡（誰、何時、從哪 IP、本機名稱、做了什麼）**
> 面板會把每次登入/部署/啟停/刪除寫進伺服器 `data/logs/audit.log`（面板「日誌→操作稽核」也看得到）。
> **AI 端強烈建議「自報本機資訊」**：在每個請求帶上以下兩個 header，伺服器直接就記錄本機名稱與作業系統帳號，**不需要伺服器反查 DNS**：
> ```powershell
> $h  = [System.Net.Dns]::GetHostName()
> $hu = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
> # 之後每個 curl 都加：
> #   -H "X-Client-Host: $h" -H "X-Client-User: $hu"
> ```
> 這樣稽核行會是（對照：沒帶 header 時 `host=-`）：
> ```
> [2026-09-01 11:35:59] user=admin ip=10.175.82.15 host=V259000047-NB action=login detail={"who": "PTB\Ziy_Yan", "result": "ok"}
> ```

```powershell
# 0) （稽核留痕）帶上本機名稱 / 作業系統帳號，讓面板直接記錄「誰」
$h  = [System.Net.Dns]::GetHostName()
$hu = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$rh = "-H `"X-Client-Host: $h`" -H `"X-Client-User: $hu`""

# 1) 登入拿 token（連登入都帶 header，稽核第一筆就完整）
$body = '{"username":"admin","password":"admin123"}'
$token = (curl.exe -s -X POST "http://10.175.22.26:8888/api/auth/login" -H "Content-Type: application/json" -H "X-Client-Host: $h" -H "X-Client-User: $hu" -d $body | ConvertFrom-Json).data.token

# 2) 若同名 app 已存在就先刪（否則 upload 回 400 "應用名稱已存在"）
curl.exe -s -X DELETE "http://10.175.22.26:8888/api/apps/myapp" -H "Authorization: Bearer $token" -H "X-Client-Host: $h" -H "X-Client-User: $hu"

# 3) 上傳 zip 部署（port 留空 → 面板自動抓 9000+；entry 填 main:app）
curl.exe -s -X POST "http://10.175.22.26:8888/api/apps/upload" `
  -H "Authorization: Bearer $token" `
  -H "X-Client-Host: $h" -H "X-Client-User: $hu" `
  -F "file=@C:\…\myapp_v1.zip;type=application/zip" `
  -F "name=myapp" -F "port=" -F "entry=main:app" -F "open_firewall=1"

# 4) 輪詢直到裝完：status 變 stopped（成功）或 error（失敗）
#    ⚠️ status 在「巢狀」的 data.app.status，不是 data.status！
#    data.app 結構：{name, port, entry, status, error, dir, url}
curl.exe -s "http://10.175.22.26:8888/api/apps/myapp" -H "Authorization: Bearer $token"
#    → 回應（查 status 要看 data.app.status）：
#       {"code":0,"msg":"ok","data":{"app":{"name":"myapp","port":9000,"status":"installing",...}}}

#    ── 完整輪詢迴圈（可直接複製，含正確欄位）──
for ($i=0; $i -lt 60; $i++) {
  $r = curl.exe -s "http://10.175.22.26:8888/api/apps/myapp" -H "Authorization: Bearer $token" | ConvertFrom-Json
  $s = $r.data.app.status        # 正確：巢狀 data.app 內
  $p = $r.data.app.port          # 正確：巢狀 data.app 內
  if ($s -eq "stopped")    { Write-Host "安裝完成 port=$p" ; break }
  if ($s -eq "error")      { Write-Host "安裝失敗 $(($r.data.app.error))" ; break }
  if ($s -in @("running")) { Write-Host "已在運行 port=$p" ; break }
  Write-Host "POLL[$i] status=$s port=$p（仍在 $s...）"
  Start-Sleep -Seconds 3
}

# 5) 啟動
curl.exe -s -X POST "http://10.175.22.26:8888/api/apps/myapp/start" -H "Authorization: Bearer $token" -H "X-Client-Host: $h" -H "X-Client-User: $hu"

# 6) 驗證 app 本身
curl http://10.175.22.26:<appPort>/health
curl http://10.175.22.26:<appPort>/

# 7) （管理員查證）看誰部署過：面板「日誌→操作稽核」或 API
curl.exe -s "http://10.175.22.26:8888/api/logs/audit?count=50" -H "Authorization: Bearer $token"
```

> 💡 `<appPort>` 從第 3 步上傳或第 4 步查詢的 `data.app.port` 取得（留空時落在 9000+）。
> 💡 安裝若 error，用 `GET /api/apps/<name>/logs` 看日誌對照 §6 錯誤表。
> 💡 不會寫 curl？直接下載自動化腳本：`http://10.175.22.26:8888/deploy_webapp.ps1`（參數帶入 IP/zip/AppName 即可，見 §4）。

---

## 3. 你的專案要準備什麼（任一 FastAPI 專案都一樣）

```
myapp_v1.zip              ← 扁平 zip（或單一資料夾，面板自動拉平）
├── main.py               ← 內含 app = FastAPI(...)（名稱：main/app/run/server/index 擇一）
└── requirements.txt      ← 一行一個依賴（全部要能在伺服器離線包找到）
```

扁平 zip 壓法（兩檔都在 zip 頂層，沒有外層資料夾）：
```powershell
Compress-Archive -Path "…\main.py","…\requirements.txt" -DestinationPath "myapp_v1.zip"
```

---

## 4. 部署流程（AI 全遠端，不需要任何人在伺服器旁）

> ⚠️ 本 SOP 假設**面板已在運行**（`GET http://IP:8888/api/health` 通）。部署 app 全程走 HTTP API。
> 只有「全新伺服器、面板還沒裝」才需要本機動作（見下方「全新伺服器」註記），一般情況不會碰到。

| 步驟 | 誰 | 做什麼 |
|---|---|---|
| 1 | AI | （前置）FTP 確認離線包有你要的套件，缺就上傳 wheel（見 §1） |
| 2 | AI | 登入面板 API 拿 token + 若同名 app 已存在先刪除 |
| 3 | AI | `POST /api/apps/upload` 上傳 zip（port 留空自動抓 9000+） |
| 4 | AI | 輪詢 `GET /api/apps/<name>` 直到 `stopped`（裝完）或 `error` |
| 5 | AI | `POST /api/apps/<name>/start` 啟動 |
| 6 | AI | 驗證 `/health` 與 `/` 都 200（見 §5） |

不需要跑任何 `.bat`、不需要本機登入。**AI 全程使用 §2 的面板 HTTP API。**

> 🔧 **面板遠端重啟（API 可達時）**：`POST /api/system/restart` 遠端自我重啟（~4 秒），不需要碰伺服器本機。
> ⚠️ **面板 API 不可達時（進程卡死 8888 無回應）**：需**能登入伺服器的人**在本機 PowerShell 強制重啟：
> ```powershell
> Get-Process python* -ErrorAction SilentlyContinue | Stop-Process -Force
> Start-Sleep -Seconds 2
> C:\bt-panel\start_panel.bat
> ```
> 然後重測 `GET http://IP:8888/api/health`。

> 🖥️ **全新伺服器（面板還沒裝）— 才需要本機動作一次**：把 `deploy\python-3.13.2-amd64.exe` 與 bt-panel 整包 FTP 放好後，**由能登入該伺服器的人**以系統管理員執行一次 `deploy\install_and_start.bat`（建 venv + 起面板）。之後 AI 就同上走純 API。
> 面板可再以系統管理員執行 `register_autostart.bat` 註冊開機自啟；往後重啟一律用 `POST /api/system/restart`。

**重用通用腳本（參數帶入，不綁專案）：**

```powershell
.\deploy_webapp.ps1 -ServerIp <面板IP> -ZipPath "C:\…\myapp_v1.zip" -AppName myapp
# 可選：-Entry main:app -User admin -Pass admin123 -PanelPort 8888
```

腳本自動：登入 → 刪同名舊 app → 抓免費端口 → 上傳(zip+entry) → 輪詢安裝 → 啟動 → 驗證 `/` 與 `/health`。
端口自動抓、名稱/進入點/zip 全由參數帶入 → **任何 FastAPI 專案都能用同一支腳本**。

> 🛡️ **這支腳本會自動「自報本機資訊」**：每次操作都帶 `X-Client-Host`（本機名稱）+ `X-Client-User`（作業系統帳號）。
> 因此只要用 `deploy_webapp.ps1` 部署，伺服器 `data/logs/audit.log` 就會留下：
> `user=admin ip=<IP> host=<你的本機名稱> action=deploy detail={"who": "<你@網域>", "name": ..., "port": ...}`
> ——**只要是 AI 用這支腳本部署，就一定有痕跡，且不需伺服器反查 DNS**。

---

## 5. 驗證

```powershell
curl http://<IP>:<appPort>/health      # → {"status":"ok"}
curl http://<IP>:<appPort>/            # → 你的網頁 HTML

# 管理員查證誰部署過（面板「日誌→操作稽核」或此 API）：
#   $h/$hu 見 §2；這指令需要已登入的 $token
curl.exe -s "http://10.175.22.26:8888/api/logs/audit?count=50" -H "Authorization: Bearer $token"
# → 每行：時間 | user= | ip= | host=<本機名稱> | action=deploy/start/... | detail= {"who":...}
```

---

## 6. 常見錯誤對照表（通用）

| 錯誤訊息 | 原因 | 解法 |
|---|---|---|
| `No matching distribution found for XXX` | 依賴不在伺服器離線包 | 補 wheel 進 `C:\bt-panel\deploy\offline_pkgs\`，或改用離線包已有的套件 |
| `無法偵測進入點` | 無 main/app/run/server/index.py，或檔內沒 `app =` | 補檔案；或上傳表單手填 entry（如 `main:app`） |
| `無法偵測進入點`（上次成功這次失敗） | 舊 app 沒刪乾淨，殘留檔擋住拉平 | 先刪舊 app 再上傳扁平 zip |
| `/` 顯示 500、`/health` 正常 | 網頁讀外部檔（如 temp HTML）失敗 | 改成直接內嵌回傳字串（勿依賴 temp 檔） |
| 改 code 沒生效 | uvicorn 不會自動重載 | 面板對 app 按「停止→啟動」 |

---

## 7. 依賴更新（換套件時）

離線包是「伺服器端實體檔案」，加了新依賴時：
1. 開發機 `pip download --only-binary :all: --python-version 313 --platform win_amd64 ... -d tmp`
2. 用 FTP 把新 .whl 傳進伺服器 `C:\bt-panel\deploy\offline_pkgs\`
3. 再重新上傳 app（會重建 venv）

---

## 8. 瀏覽器自動化（Selenium/Puppeteer）離線部署

> 若你的專案用 Selenium / Puppeteer 開瀏覽器，**不要依賴伺服器系統安裝的瀏覽器**——伺服器沒裝、或裝了版本會漂移（自動更新），driver 會失配。

### 8.1 原則：可攜式瀏覽器 + 配對 driver，一起打包進 zip

把「一組鎖定版本的可攜式瀏覽器 + 配對 driver」直接放進專案 zip，跟 main.py 一起上傳。程式碼用**專案內的絕對路徑**指到它們。版本由你鎖定 → 伺服器永遠不會版本漂移。

```
myapp_v1.zip              ← 扁平 zip
├── main.py
├── requirements.txt      ← 含 selenium（離線包須有 wheel，見 §7）
└── browser/              ← 鎖定版可攜式瀏覽器 + driver
    ├── chrome/           ← 例：Chrome 129.0.6668.xx 可攜版
    │   └── chrome.exe
    └── chromedriver.exe  ← 跟上面 Chrome 同版本的 driver
```

> 取得配對版本（Windows x64）：[Chrome for Testing](https://googlechromelabs.github.io/chrome-for-testing/)（瀏覽器 + chromedriver 同版本下載）；Edge 用微軟官方 WebDriver 頁（driver 版本=Edge 主版本）。
> ⚠️ driver 的小版本不必等於瀏覽器小版本，但**主版本（如 129）必須一致**。
> ⚠️ zip 會變大（瀏覽器約 100–300 MB），仍小於面板 1GB 上限，沒問題。

### 8.2 main.py 用專案內絕對路徑（關鍵）

```python
from pathlib import Path
from selenium import webdriver

# Path(__file__).parent = 解壓後 app 目錄，永遠指得到專案內瀏覽器
project_dir = Path(__file__).resolve().parent
browser_dir = project_dir / "browser"

options = webdriver.ChromeOptions()
options.binary_location = str(browser_dir / "chrome" / "chrome.exe")
options.add_argument("--headless=new")          # 伺服器無 GUI，務必 headless
driver = webdriver.Chrome(
    executable_path=str(browser_dir / "chromedriver.exe"),
    options=options,
)
try:
    driver.get("https://example.com")
    # ... 你的自動化邏輯 ...
finally:
    driver.quit()
```

### 8.3 驗證

```powershell
# app 起起來後，遠端確認瀏覽器可被驅動（對 app 加一支測試 API 或看日誌）
curl http://<IP>:<appPort>/your-test-endpoint
```

---

## 9. AI 快速備忘（直接照抄）

```
# ===== 前置資訊（直接拿去用）=====
面板   http://10.175.22.26:8888        （面板 IP；換機請改）
登入   admin / admin123                （面板預設；已改過問管理員）
FTP    ftp://10.175.22.26  bt / 114253..z    （只管離線包/上傳，看 §1）
離線包 /deploy/offline_pkgs/  = 伺服器 C:\bt-panel\deploy\offline_pkgs\

# ===== 部署步驟 =====
[1] FTP 確認伺服器離線包有 requirements.txt 全部依賴（缺 → 上傳 wheel，見 §1）
[2] 確認 zip 扁平（頂層 main.py + requirements.txt）
[3] 登入拿 token：POST /api/auth/login {admin,admin123} → data.token
[4] 若 app 同名已存在 → DELETE /api/apps/<name>
[5] POST /api/apps/upload：multipart file=zip, name=..., entry=main:app, port=留空（自動抓 9000+）
[6] 輪詢 GET /api/apps/<name> 直到 data.app.status=stopped（裝完）或 error
    （status 在巢狀 data.app.status，取錯欄位會一直空轉）
[7] POST /api/apps/<name>/start
[8] GET http://10.175.22.26:<port>/health 與 / → 200 即完成
[9] 失敗 → GET /api/apps/<name>/logs 看日誌，對照 §6
```
